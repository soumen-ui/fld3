const vscode = require('vscode');

function activate(context) {
  let disposable = vscode.commands.registerCommand('selfclose-fixer.runFix', async function () {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showInformationMessage('No active editor found.');
      return;
    }

    const tagInput = await vscode.window.showInputBox({
      prompt: 'Enter tag names to self-close (comma-separated, e.g., img, input, br):'
    });

    if (!tagInput) return;

    const tags = tagInput.split(',').map(t => t.trim()).join('|');
    const regex = new RegExp(`<(${tags})\b([^>]*?)(?<!/)>`, 'gi');
    const document = editor.document;
    const fullText = document.getText();

    const fixedText = fullText.replace(regex, '<$1$2 />');

    const edit = new vscode.WorkspaceEdit();
    const fullRange = new vscode.Range(
      document.positionAt(0),
      document.positionAt(fullText.length)
    );

    edit.replace(document.uri, fullRange, fixedText);
    await vscode.workspace.applyEdit(edit);

    vscode.window.showInformationMessage('Tags fixed successfully!');
  });

  context.subscriptions.push(disposable);
}

function deactivate() {}

module.exports = {
  activate,
  deactivate
};