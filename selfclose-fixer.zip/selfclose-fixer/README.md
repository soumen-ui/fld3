# SelfClose Fixer

Fix unclosed HTML tags like `<img>`, `<input>`, `<br>` by automatically converting them to `<img />`, etc.

## Usage

1. Open an HTML file.
2. Press `Ctrl+Shift+P` and run **Fix: Self-close tags**.
3. Enter tag names like `img, input, br`.
4. Done!