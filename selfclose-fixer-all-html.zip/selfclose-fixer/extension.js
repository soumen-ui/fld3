const vscode = require('vscode');
const fs = require('fs');
const path = require('path');

function activate(context) {
  let disposable = vscode.commands.registerCommand('selfclose-fixer.runFix', async function () {
    const tagInput = await vscode.window.showInputBox({
      prompt: 'Enter tag names to self-close (comma-separated, e.g., img, input, br):'
    });

    if (!tagInput) return;

    const tags = tagInput.split(',').map(t => t.trim()).join('|');
    const regex = new RegExp(`<(${tags})\b([^>]*?)(?<!/)>`, 'gi');

    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders) {
      vscode.window.showInformationMessage('No workspace folder open.');
      return;
    }

    const rootPath = workspaceFolders[0].uri.fsPath;
    const htmlFiles = [];

    function collectHtmlFiles(dir) {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (let entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          collectHtmlFiles(fullPath);
        } else if (entry.isFile() && fullPath.endsWith('.html')) {
          htmlFiles.push(fullPath);
        }
      }
    }

    collectHtmlFiles(rootPath);

    for (let file of htmlFiles) {
      const uri = vscode.Uri.file(file);
      const document = await vscode.workspace.openTextDocument(uri);
      const text = document.getText();
      const fixedText = text.replace(regex, '<$1$2 />');

      const edit = new vscode.WorkspaceEdit();
      const fullRange = new vscode.Range(
        document.positionAt(0),
        document.positionAt(text.length)
      );

      edit.replace(uri, fullRange, fixedText);
      await vscode.workspace.applyEdit(edit);
      await document.save();
    }

    vscode.window.showInformationMessage(`Fixed ${htmlFiles.length} HTML file(s)`);
  });

  context.subscriptions.push(disposable);
}

function deactivate() {}

module.exports = {
  activate,
  deactivate
};